from django.contrib import admin
from .models import Category, Product, Sale, SaleItem, StockAdjustment


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'product_code', 'category', 'unit_price', 'stock_quantity', 'stock_status', 'created_at']
    list_filter = ['category']
    search_fields = ['name', 'product_code']
    
    def stock_status(self, obj):
        if obj.is_out_of_stock():
            return '🔴 Out of Stock'
        elif obj.is_low_stock():
            return '🟡 Low Stock'
        else:
            return '🟢 In Stock'
    stock_status.short_description = 'Status'


class SaleItemInline(admin.TabularInline):
    model = SaleItem
    extra = 0
    readonly_fields = ['total_price']


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ['invoice_number', 'date', 'subtotal', 'vat_amount', 'discount_amount', 'total']
    list_filter = ['date']
    search_fields = ['invoice_number']
    readonly_fields = ['invoice_number', 'created_at']
    inlines = [SaleItemInline]


@admin.register(StockAdjustment)
class StockAdjustmentAdmin(admin.ModelAdmin):
    list_display = ['product', 'adjustment_type', 'quantity_change', 'previous_quantity', 'new_quantity', 'created_at']
    list_filter = ['adjustment_type', 'created_at']
    search_fields = ['product__name', 'reason']
    readonly_fields = ['previous_quantity', 'new_quantity', 'created_at']
