from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Sum, Count, Q, F
from django.db import models
from django.http import HttpResponse, JsonResponse
from django.conf import settings
from decimal import Decimal
from datetime import datetime, timedelta
from .models import Product, Category, Sale, SaleItem, StockAdjustment
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
import io


def dashboard(request):
    """Main dashboard with quick stats"""
    today = datetime.now().date()
    today_sales = Sale.objects.filter(date__date=today)
    
    # Stock statistics
    low_stock_products = Product.objects.filter(stock_quantity__lte=models.F('low_stock_threshold')).count()
    out_of_stock_products = Product.objects.filter(stock_quantity=0).count()
    
    context = {
        'total_products': Product.objects.count(),
        'total_categories': Category.objects.count(),
        'today_sales_count': today_sales.count(),
        'today_revenue': today_sales.aggregate(Sum('total'))['total__sum'] or 0,
        'low_stock_count': low_stock_products,
        'out_of_stock_count': out_of_stock_products,
    }
    return render(request, 'pos/dashboard.html', context)


def product_list(request):
    """List all products"""
    products = Product.objects.select_related('category').all()
    categories = Category.objects.all()
    return render(request, 'pos/product_list.html', {'products': products, 'categories': categories})


def product_bulk_upload(request):
    """Bulk upload products via CSV"""
    if request.method == 'POST':
        if 'csv_file' not in request.FILES:
            messages.error(request, 'No file uploaded!')
            return redirect('product_bulk_upload')
        
        csv_file = request.FILES['csv_file']
        
        # Validate file extension
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File must be a CSV!')
            return redirect('product_bulk_upload')
        
        try:
            # Read CSV file
            import csv
            import io
            
            decoded_file = csv_file.read().decode('utf-8')
            io_string = io.StringIO(decoded_file)
            reader = csv.DictReader(io_string)
            
            success_count = 0
            error_count = 0
            errors = []
            
            for row_num, row in enumerate(reader, start=2):  # Start at 2 (1 is header)
                try:
                    # Get or create category
                    category = None
                    if row.get('category'):
                        category, _ = Category.objects.get_or_create(name=row['category'].strip())
                    
                    # Prepare product data
                    product_code = row.get('product_code', '').strip() or None
                    stock_quantity = int(row.get('stock_quantity', 0))
                    low_stock_threshold = int(row.get('low_stock_threshold', 10))
                    
                    # Check if product exists (by name or code)
                    existing_product = None
                    if product_code:
                        existing_product = Product.objects.filter(product_code=product_code).first()
                    if not existing_product:
                        existing_product = Product.objects.filter(name=row['name'].strip()).first()
                    
                    if existing_product:
                        # Update existing product
                        existing_product.name = row['name'].strip()
                        existing_product.product_code = product_code
                        existing_product.category = category
                        existing_product.unit_price = Decimal(row['unit_price'])
                        existing_product.low_stock_threshold = low_stock_threshold
                        
                        # Update stock if provided and different
                        if stock_quantity != existing_product.stock_quantity:
                            previous_qty = existing_product.stock_quantity
                            existing_product.stock_quantity = stock_quantity
                            
                            # Create stock adjustment record
                            StockAdjustment.objects.create(
                                product=existing_product,
                                adjustment_type='correction',
                                quantity_change=stock_quantity - previous_qty,
                                previous_quantity=previous_qty,
                                new_quantity=stock_quantity,
                                reason=f'CSV bulk upload - Row {row_num}'
                            )
                        
                        existing_product.save()
                        success_count += 1
                    else:
                        # Create new product
                        product = Product.objects.create(
                            name=row['name'].strip(),
                            product_code=product_code,
                            category=category,
                            unit_price=Decimal(row['unit_price']),
                            stock_quantity=stock_quantity,
                            low_stock_threshold=low_stock_threshold
                        )
                        
                        # Create initial stock adjustment if stock > 0
                        if stock_quantity > 0:
                            StockAdjustment.objects.create(
                                product=product,
                                adjustment_type='restock',
                                quantity_change=stock_quantity,
                                previous_quantity=0,
                                new_quantity=stock_quantity,
                                reason=f'CSV bulk upload - Row {row_num}'
                            )
                        
                        success_count += 1
                        
                except Exception as e:
                    error_count += 1
                    errors.append(f"Row {row_num}: {str(e)}")
            
            # Show results
            if success_count > 0:
                messages.success(request, f'Successfully processed {success_count} product(s)!')
            if error_count > 0:
                error_msg = f'{error_count} error(s) occurred:<br>' + '<br>'.join(errors[:10])
                if len(errors) > 10:
                    error_msg += f'<br>...and {len(errors) - 10} more errors'
                messages.error(request, error_msg)
            
            return redirect('product_list')
            
        except Exception as e:
            messages.error(request, f'Error processing CSV file: {str(e)}')
            return redirect('product_bulk_upload')
    
    return render(request, 'pos/product_bulk_upload.html')


def product_export_csv(request):
    """Export products as CSV"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="products_export.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['name', 'product_code', 'category', 'unit_price', 'stock_quantity', 'low_stock_threshold'])
    
    products = Product.objects.select_related('category').all()
    for product in products:
        writer.writerow([
            product.name,
            product.product_code or '',
            product.category.name if product.category else '',
            product.unit_price,
            product.stock_quantity,
            product.low_stock_threshold
        ])
    
    return response


def product_download_template(request):
    """Download CSV template for bulk upload"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="product_upload_template.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['name', 'product_code', 'category', 'unit_price', 'stock_quantity', 'low_stock_threshold'])
    
    # Add sample rows
    writer.writerow(['Sample Product 1', 'PROD001', 'Electronics', '1500.00', '50', '10'])
    writer.writerow(['Sample Product 2', 'PROD002', 'Groceries', '250.50', '100', '20'])
    writer.writerow(['Sample Product 3', '', 'Beverages', '80.00', '75', '15'])
    
    return response


def product_create(request):
    """Create new product"""
    if request.method == 'POST':
        name = request.POST.get('name')
        product_code = request.POST.get('product_code')
        category_id = request.POST.get('category')
        unit_price = request.POST.get('unit_price')
        stock_quantity = request.POST.get('stock_quantity', 0)
        low_stock_threshold = request.POST.get('low_stock_threshold', 10)
        
        try:
            category = Category.objects.get(id=category_id) if category_id else None
            product = Product.objects.create(
                name=name, 
                product_code=product_code if product_code else None,
                category=category, 
                unit_price=unit_price,
                stock_quantity=int(stock_quantity),
                low_stock_threshold=int(low_stock_threshold)
            )
            
            # Create initial stock adjustment record
            if int(stock_quantity) > 0:
                StockAdjustment.objects.create(
                    product=product,
                    adjustment_type='restock',
                    quantity_change=int(stock_quantity),
                    previous_quantity=0,
                    new_quantity=int(stock_quantity),
                    reason='Initial stock'
                )
            
            messages.success(request, 'Product created successfully!')
            return redirect('product_list')
        except Exception as e:
            messages.error(request, f'Error creating product: {str(e)}')
    
    categories = Category.objects.all()
    return render(request, 'pos/product_form.html', {'categories': categories})


def product_edit(request, pk):
    """Edit existing product"""
    product = get_object_or_404(Product, pk=pk)
    
    if request.method == 'POST':
        product.name = request.POST.get('name')
        product.product_code = request.POST.get('product_code') if request.POST.get('product_code') else None
        category_id = request.POST.get('category')
        product.category = Category.objects.get(id=category_id) if category_id else None
        product.unit_price = request.POST.get('unit_price')
        product.low_stock_threshold = int(request.POST.get('low_stock_threshold', 10))
        product.save()
        messages.success(request, 'Product updated successfully!')
        return redirect('product_list')
    
    categories = Category.objects.all()
    return render(request, 'pos/product_form.html', {'product': product, 'categories': categories})


def product_delete(request, pk):
    """Delete product"""
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        messages.success(request, 'Product deleted successfully!')
        return redirect('product_list')
    return render(request, 'pos/product_confirm_delete.html', {'product': product})


def category_list(request):
    """List all categories"""
    categories = Category.objects.all()
    return render(request, 'pos/category_list.html', {'categories': categories})


def category_create(request):
    """Create new category"""
    if request.method == 'POST':
        name = request.POST.get('name')
        try:
            Category.objects.create(name=name)
            messages.success(request, 'Category created successfully!')
            return redirect('category_list')
        except Exception as e:
            messages.error(request, f'Error creating category: {str(e)}')
    return render(request, 'pos/category_form.html')


def pos_screen(request):
    """Main POS sales screen"""
    products = Product.objects.select_related('category').all()
    categories = Category.objects.all()
    vat_rate = getattr(settings, 'VAT_RATE', 16)
    
    context = {
        'products': products,
        'categories': categories,
        'vat_rate': vat_rate,
    }
    return render(request, 'pos/pos_screen.html', context)


def complete_sale(request):
    """Process and complete a sale"""
    if request.method == 'POST':
        try:
            # Get sale data
            items_data = request.POST.getlist('items')
            discount_type = request.POST.get('discount_type', 'percentage')
            discount_value = Decimal(request.POST.get('discount_value', 0))
            vat_rate = Decimal(getattr(settings, 'VAT_RATE', 16))
            
            if not items_data:
                messages.error(request, 'No items in cart!')
                return redirect('pos_screen')
            
            # Calculate totals and check stock
            subtotal = Decimal(0)
            sale_items = []
            
            for item_str in items_data:
                product_id, quantity, price = item_str.split(',')
                product = Product.objects.get(id=product_id)
                quantity = int(quantity)
                unit_price = Decimal(price)
                total_price = unit_price * quantity
                
                # Check stock availability
                if not product.has_sufficient_stock(quantity):
                    messages.error(request, f'Insufficient stock for {product.name}. Available: {product.stock_quantity}')
                    return redirect('pos_screen')
                
                subtotal += total_price
                sale_items.append({
                    'product': product,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'total_price': total_price
                })
            
            # Calculate discount
            if discount_type == 'percentage':
                discount_amount = (subtotal * discount_value) / 100
            else:
                discount_amount = discount_value
            
            # Calculate VAT on discounted amount
            amount_after_discount = subtotal - discount_amount
            vat_amount = (amount_after_discount * vat_rate) / 100
            total = amount_after_discount + vat_amount
            
            # Create sale
            sale = Sale.objects.create(
                subtotal=subtotal,
                vat_rate=vat_rate,
                vat_amount=vat_amount,
                discount_type=discount_type,
                discount_value=discount_value,
                discount_amount=discount_amount,
                total=total
            )
            
            # Create sale items and deduct stock
            for item in sale_items:
                SaleItem.objects.create(
                    sale=sale,
                    product=item['product'],
                    quantity=item['quantity'],
                    unit_price=item['unit_price']
                )
                
                # Deduct stock and create adjustment record
                previous_qty = item['product'].stock_quantity
                item['product'].deduct_stock(item['quantity'])
                
                StockAdjustment.objects.create(
                    product=item['product'],
                    adjustment_type='sale',
                    quantity_change=-item['quantity'],
                    previous_quantity=previous_qty,
                    new_quantity=item['product'].stock_quantity,
                    reason=f'Sale: {sale.invoice_number}'
                )
            
            messages.success(request, f'Sale completed! Invoice: {sale.invoice_number}')
            return redirect('invoice_view', pk=sale.pk)
            
        except Exception as e:
            messages.error(request, f'Error completing sale: {str(e)}')
            return redirect('pos_screen')
    
    return redirect('pos_screen')


def invoice_view(request, pk):
    """View invoice details"""
    sale = get_object_or_404(Sale, pk=pk)
    shop_name = getattr(settings, 'SHOP_NAME', 'My Retail Shop')
    return render(request, 'pos/invoice.html', {'sale': sale, 'shop_name': shop_name})


def invoice_pdf(request, pk):
    """Generate PDF invoice"""
    sale = get_object_or_404(Sale, pk=pk)
    shop_name = getattr(settings, 'SHOP_NAME', 'My Retail Shop')
    
    # Create PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], alignment=TA_CENTER)
    elements.append(Paragraph(shop_name, title_style))
    elements.append(Spacer(1, 0.2*inch))
    
    # Invoice details
    invoice_style = ParagraphStyle('InvoiceDetails', parent=styles['Normal'], fontSize=10)
    elements.append(Paragraph(f"<b>Invoice Number:</b> {sale.invoice_number}", invoice_style))
    elements.append(Paragraph(f"<b>Date:</b> {sale.date.strftime('%d/%m/%Y %H:%M')}", invoice_style))
    elements.append(Spacer(1, 0.3*inch))
    
    # Items table
    data = [['Item', 'Qty', 'Price', 'Total']]
    for item in sale.items.all():
        data.append([
            item.product.name,
            str(item.quantity),
            f'KES {item.unit_price:,.2f}',
            f'KES {item.total_price:,.2f}'
        ])
    
    # Add totals
    data.append(['', '', 'Subtotal:', f'KES {sale.subtotal:,.2f}'])
    if sale.discount_amount > 0:
        data.append(['', '', f'Discount ({sale.discount_value}{"%" if sale.discount_type == "percentage" else ""}):', f'KES {sale.discount_amount:,.2f}'])
    data.append(['', '', f'VAT ({sale.vat_rate}%):', f'KES {sale.vat_amount:,.2f}'])
    data.append(['', '', '<b>TOTAL:</b>', f'<b>KES {sale.total:,.2f}</b>'])
    
    table = Table(data, colWidths=[3*inch, 1*inch, 1.5*inch, 1.5*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -5), 1, colors.black),
        ('LINEBELOW', (2, -4), (-1, -4), 1, colors.black),
        ('LINEBELOW', (2, -1), (-1, -1), 2, colors.black),
    ]))
    
    elements.append(table)
    elements.append(Spacer(1, 0.5*inch))
    elements.append(Paragraph("Thank you for your business!", styles['Normal']))
    
    doc.build(elements)
    buffer.seek(0)
    
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="invoice_{sale.invoice_number}.pdf"'
    return response


def sales_report(request):
    """Daily sales report"""
    # Get date filter
    date_str = request.GET.get('date')
    if date_str:
        try:
            filter_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except:
            filter_date = datetime.now().date()
    else:
        filter_date = datetime.now().date()
    
    # Get sales for the date
    sales = Sale.objects.filter(date__date=filter_date).prefetch_related('items')
    
    # Calculate summary
    summary = sales.aggregate(
        total_sales=Sum('total'),
        total_vat=Sum('vat_amount'),
        total_discounts=Sum('discount_amount'),
        transaction_count=Count('id')
    )
    
    context = {
        'sales': sales,
        'filter_date': filter_date,
        'summary': summary,
    }
    return render(request, 'pos/sales_report.html', context)


def search_product_by_code(request):
    """API endpoint to search product by barcode/product code"""
    code = request.GET.get('code', '').strip()
    
    if not code:
        return JsonResponse({'error': 'No code provided'}, status=400)
    
    try:
        product = Product.objects.get(product_code=code)
        return JsonResponse({
            'success': True,
            'product': {
                'id': product.id,
                'name': product.name,
                'product_code': product.product_code,
                'price': float(product.unit_price),
                'category': product.category.name if product.category else None,
                'stock_quantity': product.stock_quantity,
                'in_stock': not product.is_out_of_stock()
            }
        })
    except Product.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': f'Product with code "{code}" not found'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


def stock_list(request):
    """View all products with stock information"""
    # Filter options
    status_filter = request.GET.get('status', 'all')
    
    products = Product.objects.select_related('category').all()
    
    if status_filter == 'low':
        products = products.filter(stock_quantity__lte=models.F('low_stock_threshold'))
    elif status_filter == 'out':
        products = products.filter(stock_quantity=0)
    
    context = {
        'products': products,
        'status_filter': status_filter,
    }
    return render(request, 'pos/stock_list.html', context)


def stock_adjust(request, pk):
    """Adjust stock for a product"""
    product = get_object_or_404(Product, pk=pk)
    
    if request.method == 'POST':
        adjustment_type = request.POST.get('adjustment_type')
        quantity_change = int(request.POST.get('quantity_change', 0))
        reason = request.POST.get('reason', '')
        
        if quantity_change == 0:
            messages.error(request, 'Quantity change cannot be zero!')
            return redirect('stock_adjust', pk=pk)
        
        try:
            previous_qty = product.stock_quantity
            
            if quantity_change > 0:
                product.add_stock(quantity_change)
            else:
                if not product.has_sufficient_stock(abs(quantity_change)):
                    messages.error(request, 'Cannot deduct more than available stock!')
                    return redirect('stock_adjust', pk=pk)
                product.deduct_stock(abs(quantity_change))
            
            # Create adjustment record
            StockAdjustment.objects.create(
                product=product,
                adjustment_type=adjustment_type,
                quantity_change=quantity_change,
                previous_quantity=previous_qty,
                new_quantity=product.stock_quantity,
                reason=reason
            )
            
            messages.success(request, f'Stock adjusted successfully! New quantity: {product.stock_quantity}')
            return redirect('stock_list')
            
        except Exception as e:
            messages.error(request, f'Error adjusting stock: {str(e)}')
    
    return render(request, 'pos/stock_adjust.html', {'product': product})


def stock_history(request, pk):
    """View stock adjustment history for a product"""
    product = get_object_or_404(Product, pk=pk)
    adjustments = product.stock_adjustments.all()
    
    context = {
        'product': product,
        'adjustments': adjustments,
    }
    return render(request, 'pos/stock_history.html', context)


def low_stock_alert(request):
    """View products with low or out of stock"""
    low_stock = Product.objects.filter(
        stock_quantity__lte=models.F('low_stock_threshold'),
        stock_quantity__gt=0
    ).select_related('category')
    
    out_of_stock = Product.objects.filter(stock_quantity=0).select_related('category')
    
    context = {
        'low_stock_products': low_stock,
        'out_of_stock_products': out_of_stock,
    }
    return render(request, 'pos/low_stock_alert.html', context)
