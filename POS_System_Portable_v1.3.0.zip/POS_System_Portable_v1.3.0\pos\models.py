from django.db import models
from django.utils import timezone
from decimal import Decimal


class Category(models.Model):
    """Product categories for organization"""
    name = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

    def __str__(self):
        return self.name


class Product(models.Model):
    """Products available for sale"""
    name = models.CharField(max_length=200)
    product_code = models.CharField(max_length=50, unique=True, blank=True, null=True, help_text="Barcode or product code for scanning")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name='products')
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.IntegerField(default=0, help_text="Current stock quantity")
    low_stock_threshold = models.IntegerField(default=10, help_text="Alert when stock falls below this level")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name} - KES {self.unit_price}"
    
    def is_low_stock(self):
        """Check if product is low on stock"""
        return self.stock_quantity <= self.low_stock_threshold
    
    def is_out_of_stock(self):
        """Check if product is out of stock"""
        return self.stock_quantity <= 0
    
    def has_sufficient_stock(self, quantity):
        """Check if there's enough stock for a sale"""
        return self.stock_quantity >= quantity
    
    def deduct_stock(self, quantity):
        """Deduct stock after a sale"""
        if self.has_sufficient_stock(quantity):
            self.stock_quantity -= quantity
            self.save()
            return True
        return False
    
    def add_stock(self, quantity):
        """Add stock (for restocking)"""
        self.stock_quantity += quantity
        self.save()
    
    @property
    def stock_status(self):
        """Get stock status as string"""
        if self.is_out_of_stock():
            return "Out of Stock"
        elif self.is_low_stock():
            return "Low Stock"
        else:
            return "In Stock"


class Sale(models.Model):
    """Sales transactions"""
    invoice_number = models.CharField(max_length=20, unique=True, editable=False)
    date = models.DateTimeField(default=timezone.now)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    vat_rate = models.DecimalField(max_digits=5, decimal_places=2, default=16)
    vat_amount = models.DecimalField(max_digits=10, decimal_places=2)
    discount_type = models.CharField(max_length=10, choices=[('percentage', 'Percentage'), ('fixed', 'Fixed')], default='percentage')
    discount_value = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"Invoice {self.invoice_number} - KES {self.total}"

    def save(self, *args, **kwargs):
        if not self.invoice_number:
            # Generate invoice number: INV-YYYYMMDD-XXXX
            today = timezone.now()
            date_str = today.strftime('%Y%m%d')
            last_sale = Sale.objects.filter(invoice_number__startswith=f'INV-{date_str}').order_by('-invoice_number').first()
            if last_sale:
                last_num = int(last_sale.invoice_number.split('-')[-1])
                new_num = last_num + 1
            else:
                new_num = 1
            self.invoice_number = f'INV-{date_str}-{new_num:04d}'
        super().save(*args, **kwargs)


class SaleItem(models.Model):
    """Individual items in a sale"""
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

    def save(self, *args, **kwargs):
        self.total_price = Decimal(self.quantity) * self.unit_price
        super().save(*args, **kwargs)


class StockAdjustment(models.Model):
    """Track stock adjustments and changes"""
    ADJUSTMENT_TYPES = [
        ('restock', 'Restock'),
        ('damage', 'Damage/Loss'),
        ('return', 'Customer Return'),
        ('correction', 'Stock Correction'),
        ('sale', 'Sale'),
    ]
    
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='stock_adjustments')
    adjustment_type = models.CharField(max_length=20, choices=ADJUSTMENT_TYPES)
    quantity_change = models.IntegerField(help_text="Positive for additions, negative for deductions")
    previous_quantity = models.IntegerField()
    new_quantity = models.IntegerField()
    reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.product.name} - {self.adjustment_type} ({self.quantity_change:+d})"
