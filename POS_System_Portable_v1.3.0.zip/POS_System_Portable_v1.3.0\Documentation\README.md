# Point of Sale (POS) System

A minimal, fast, and production-ready POS system built with Django for small retail shops in Kenya.

## Features

### Core Functionality
- **Product Management**: Create, update, and delete products with categories
- **POS Sales Screen**: Fast product selection with real-time cart updates
- **Automatic Calculations**: Subtotal, VAT (16%), discounts, and total
- **Invoice Generation**: Clean receipts with PDF download and print support
- **Sales Reports**: Daily summaries with transaction details
- **Kenya VAT Handling**: Configurable 16% VAT rate

### Key Highlights
- Clean, responsive Bootstrap UI
- Fast search and category filtering
- Auto-generated invoice numbers
- Multiple discount types (percentage/fixed)
- Easy to extend for future features

## Technology Stack

- **Backend**: Django 4.2.7 (LTS)
- **Database**: SQLite (development) / PostgreSQL (production)
- **Frontend**: Django Templates + Bootstrap 5
- **PDF Generation**: ReportLab
- **Timezone**: Africa/Nairobi

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Clone or Download
```bash
cd your-project-folder
```

### Step 2: Create Virtual Environment (Recommended)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment (Optional)
Copy `.env.example` to `.env` and customize:
```bash
copy .env.example .env  # Windows
cp .env.example .env    # Linux/Mac
```

Edit `.env` to customize:
- `SHOP_NAME`: Your shop name
- `VAT_RATE`: VAT percentage (default: 16)
- `SECRET_KEY`: Django secret key (generate new for production)

### Step 5: Run Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 6: Create Admin User
```bash
python manage.py createsuperuser
```
Follow prompts to create your admin account.

### Step 7: Load Sample Data (Optional)
```bash
python manage.py seed_data
```
This creates sample categories and products for testing.

### Step 8: Run Development Server
```bash
python manage.py runserver
```

Access the application:
- **Main App**: http://127.0.0.1:8000/
- **Admin Panel**: http://127.0.0.1:8000/admin/

## Usage Guide

### 1. Product Management
- Navigate to **Products** from the menu
- Click **Add Product** to create new products
- Assign categories for better organization
- Set unit prices in KES

### 2. Making a Sale
1. Click **New Sale** from dashboard or menu
2. Click on products to add them to cart
3. Adjust quantities as needed
4. Apply discounts if applicable (percentage or fixed amount)
5. Review totals (Subtotal, VAT, Discount, Total)
6. Click **Complete Sale**
7. View/print/download invoice

### 3. Viewing Reports
- Navigate to **Reports** from menu
- Select date to view daily sales
- See summary: Total sales, VAT collected, discounts, transaction count
- Click **View** on any transaction to see invoice details

### 4. Managing Categories
- Navigate to **Categories** from menu
- Add categories to organize products
- View product count per category

## Project Structure

```
pos_system/
├── pos/                          # Main POS app
│   ├── models.py                 # Database models
│   ├── views.py                  # Business logic
│   ├── urls.py                   # URL routing
│   ├── admin.py                  # Admin configuration
│   ├── templates/pos/            # HTML templates
│   │   ├── base.html            # Base template
│   │   ├── dashboard.html       # Dashboard
│   │   ├── pos_screen.html      # POS sales screen
│   │   ├── invoice.html         # Invoice view
│   │   ├── product_list.html    # Product listing
│   │   ├── sales_report.html    # Sales reports
│   │   └── ...
│   └── management/commands/
│       └── seed_data.py         # Sample data seeder
├── pos_system/                   # Project settings
│   ├── settings.py              # Django settings
│   ├── urls.py                  # Main URL config
│   └── wsgi.py                  # WSGI config
├── manage.py                     # Django management
├── requirements.txt              # Python dependencies
├── .env.example                  # Environment template
└── README.md                     # This file
```

## Database Models

### Category
- `name`: Category name (unique)
- `created_at`: Creation timestamp

### Product
- `name`: Product name
- `category`: Foreign key to Category
- `unit_price`: Price in KES
- `created_at`, `updated_at`: Timestamps

### Sale
- `invoice_number`: Auto-generated (INV-YYYYMMDD-XXXX)
- `date`: Sale timestamp
- `subtotal`: Total before VAT and discount
- `vat_rate`, `vat_amount`: VAT details
- `discount_type`, `discount_value`, `discount_amount`: Discount details
- `total`: Final amount

### SaleItem
- `sale`: Foreign key to Sale
- `product`: Foreign key to Product
- `quantity`: Number of items
- `unit_price`: Price at time of sale
- `total_price`: Quantity × Unit Price

## Configuration

### VAT Rate
Edit `pos_system/settings.py`:
```python
VAT_RATE = 16  # Change to your desired rate
```

### Shop Name
Edit `pos_system/settings.py`:
```python
SHOP_NAME = 'Your Shop Name'
```

### Database (PostgreSQL for Production)
1. Install PostgreSQL and psycopg2:
```bash
pip install psycopg2-binary
```

2. Update `settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'pos_db',
        'USER': 'your_user',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

## Extending the System

### Future Enhancements (Easy to Add)
- **Stock Management**: Track inventory levels
- **Multiple Users**: Add user authentication and roles
- **M-PESA Integration**: Accept mobile payments
- **Customer Management**: Track customer purchases
- **Barcode Scanning**: Quick product lookup
- **Multi-store Support**: Manage multiple locations
- **Advanced Reports**: Charts, graphs, profit margins

### Adding New Features
1. Update models in `pos/models.py`
2. Create/update views in `pos/views.py`
3. Add URL routes in `pos/urls.py`
4. Create templates in `pos/templates/pos/`
5. Run migrations: `python manage.py makemigrations && python manage.py migrate`

## Troubleshooting

### Port Already in Use
```bash
python manage.py runserver 8001
```

### Database Errors
```bash
# Reset database (WARNING: Deletes all data)
del db.sqlite3
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_data
```

### Static Files Not Loading
```bash
python manage.py collectstatic
```

## Production Deployment

### Security Checklist
1. Set `DEBUG = False` in settings.py
2. Generate new `SECRET_KEY`
3. Update `ALLOWED_HOSTS`
4. Use PostgreSQL instead of SQLite
5. Configure static files serving
6. Enable HTTPS
7. Set up proper backup system

### Recommended Hosting
- **Heroku**: Easy deployment with PostgreSQL
- **DigitalOcean**: VPS with full control
- **PythonAnywhere**: Simple Django hosting
- **AWS/Azure**: Enterprise-grade infrastructure

## Support & Contribution

### Getting Help
- Check Django documentation: https://docs.djangoproject.com/
- Review code comments in views.py and models.py
- Test with sample data using `seed_data` command

### Contributing
Feel free to extend this system for your needs. The code is well-commented and follows Django best practices.

## License

This project is open-source and available for commercial use.

## Author

Built with ❤️ for Kenyan retail shops

---

**Version**: 1.0.0  
**Last Updated**: February 2026
